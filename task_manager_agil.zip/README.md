# Task Manager Ágil

## 🎯 Objetivo
Desenvolver um sistema de gerenciamento de tarefas com base em metodologias ágeis, permitindo criar, listar, atualizar e excluir tarefas.

## ⚙️ Tecnologias utilizadas
- Python 3
- Flask
- Pytest
- GitHub Actions

## 🧠 Metodologia
Utilizamos Kanban para organização das tarefas no GitHub Projects, com colunas: A Fazer, Em Progresso e Concluído.

## 🚀 Como executar
1. Clone o repositório.
2. Crie um ambiente virtual: `python -m venv venv`
3. Ative o ambiente virtual:
   - Windows: `venv\Scripts\activate`
   - Linux/Mac: `source venv/bin/activate`
4. Instale as dependências: `pip install flask`
5. Execute o app: `python src/app.py`

## 🔁 Mudança de Escopo
Inicialmente planejamos um CRUD básico. Após reavaliação, decidimos adicionar uma camada de testes automatizados e pipeline com GitHub Actions para melhorar o controle de qualidade.
