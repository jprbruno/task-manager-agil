from flask import Flask, jsonify, request

app = Flask(__name__)
tarefas = []
contador = 1

@app.route('/tarefas', methods=['POST'])
def criar_tarefa():
    global contador
    dados = request.get_json()
    tarefa = {"id": contador, "titulo": dados.get("titulo", ""), "feito": False}
    tarefas.append(tarefa)
    contador += 1
    return jsonify(tarefa), 201

@app.route('/tarefas', methods=['GET'])
def listar_tarefas():
    return jsonify(tarefas), 200

@app.route('/tarefas/<int:id>', methods=['PUT'])
def atualizar_tarefa(id):
    for tarefa in tarefas:
        if tarefa["id"] == id:
            tarefa["feito"] = not tarefa["feito"]
            return jsonify(tarefa), 200
    return jsonify({"erro": "Tarefa não encontrada"}), 404

@app.route('/tarefas/<int:id>', methods=['DELETE'])
def deletar_tarefa(id):
    global tarefas
    tarefas = [t for t in tarefas if t["id"] != id]
    return jsonify({"msg": "Tarefa deletada"}), 200

if __name__ == '__main__':
    app.run(debug=True)
