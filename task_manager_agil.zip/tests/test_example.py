def test_soma_basica():
    assert 1 + 1 == 2
